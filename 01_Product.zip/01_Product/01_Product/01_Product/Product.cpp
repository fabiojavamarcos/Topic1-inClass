//
//  Product.cpp
//  01_Product
//
//  Created by Fabio Marcos De Abreu Santos on 9/26/23.
//

#include "Product.hpp"
#include "Product.h"
using namespace std;

Product::Product(const string& code, const string& desc, double p)
    : productCode(code), description(desc), price(p) {
        
    }

string Product::getProductCode() const {
    return productCode;
}

string Product::getDescription() const {
    return description;
}

double Product::getPrice() const {
    return price;
}

void Product::setProductCode(const string& code) {
    productCode = code;
}

void Product::setProductCodeEasy(string code) {
    productCode = code;
}

void Product::setDescription(const string& desc) {
    description = desc;
}

void Product::setPrice(double p) {
    price = p;
}
