//
//  Product.h
//  01_Product
//
//  Created by Fabio Marcos De Abreu Santos on 9/26/23.
//

#ifndef Product_h
#define Product_h


#endif /* Product_h */
#pragma once

#include <string>
using namespace std;

class Product {
private:
    std::string productCode;
    std::string description;
    double price;

public:
    Product(const std::string& code, const std::string& desc, double p);
    std::string getProductCode() const;
    std::string getDescription() const;
    double getPrice() const;
    void setProductCode(const std::string& code);
    void setProductCodeEasy(string code);
    void setDescription(const std::string& desc);
    void setPrice(double p);
};
