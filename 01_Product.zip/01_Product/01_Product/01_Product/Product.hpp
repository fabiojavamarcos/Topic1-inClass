//
//  Product.hpp
//  01_Product
//
//  Created by Fabio Marcos De Abreu Santos on 9/26/23.
//

#ifndef Product_hpp
#define Product_hpp

#include <stdio.h>

#endif /* Product_hpp */
