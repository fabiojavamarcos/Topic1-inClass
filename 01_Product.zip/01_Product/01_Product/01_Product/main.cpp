//
//  main.cpp
//  01_Product
//
//  Created by Fabio Marcos De Abreu Santos on 9/24/23.
//

#include <iostream>
#include <string>
#include "product.h"

using namespace std;

int main(int argc, const char * argv[]) {
    Product product("P001", "Sample Product", 19.99);

    cout << "Product Code: " << product.getProductCode() << endl;
    cout << "Description: " << product.getDescription() << endl;
    cout << "Price: $" << product.getPrice() << endl;

    product.setPrice(24.99);
    cout << "Updated Price: $" << product.getPrice() << endl;
    
    product.setProductCode("P001a");
    cout << "Updated Code: " << product.getProductCode() << endl;

    product.setProductCodeEasy("P001b");
    cout << "Updated Code Easy: " << product.getProductCode() << endl;

    return 0;
}
